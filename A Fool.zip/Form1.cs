﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button_Yes_Click(object sender, EventArgs e)
        {
            MessageBox.Show("HAHAHA");
        }

        private void Button_No_MouseMove(object sender, MouseEventArgs e)
        {
        }

        private void Button_No_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yes");
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            int x = MousePosition.X - this.Location.X;
            int y = MousePosition.Y - this.Location.Y;
            if ((Button_No.Location.X - 40 < x) && (x < Button_No.Location.X + Button_No.Width + 40))
            {
                if (Button_No.Location.Y > y && Button_No.Location.Y - y < 40)
                {
                    Button_No.Location = new Point(Button_No.Location.X, Button_No.Location.Y + 40);
                }
                else if (Button_No.Location.Y + Button_No.Height < y && y - Button_No.Location.Y - Button_No.Height < 80)
                {
                    Button_No.Location = new Point(Button_No.Location.X, Button_No.Location.Y - 40);
                }
            }
            if ((Button_No.Location.Y - y < 40) && (y - Button_No.Location.Y - Button_No.Height < 40))
            {
                if ((Button_No.Location.X > x) && (Button_No.Location.X - x < 40))
                {
                    Button_No.Location = new Point(Button_No.Location.X + 40, Button_No.Location.Y);
                }
                else if ((Button_No.Location.X + Button_No.Width < x) && (x - Button_No.Location.X - Button_No.Width < 40))
                {
                    Button_No.Location = new Point(Button_No.Location.X - 40, Button_No.Location.Y);
                }
            }
            if (Button_No.Location.X - Button_Yes.Location.X - Button_Yes.Width < 30 &&   Button_Yes.Location.X - Button_No.Location.X - Button_No.Width < 30)
            {
                if (Button_Yes.Location.Y - Button_No.Location.Y < 30 &&
                Button_No.Location.Y - Button_Yes.Location.Y - Button_Yes.Height <  30)
                {
                    Button_No.Location = new Point(25, 25);
                }
                if (Button_No.Location.Y + Button_No.Height + 30 > Button_Yes.Location.Y &&
                Button_No.Location.Y + Button_No.Height - Button_Yes.Location.Y - Button_Yes.Height < 30)
                {
                    Button_No.Location = new Point(25, 25);
                }
            }
            if (Button_No.Location.X - label1.Location.X - label1.Width < 30 && label1.Location.X - Button_No.Location.X - Button_No.Width < 30)
            {
                if (label1.Location.Y - Button_No.Location.Y < 30 &&
                Button_No.Location.Y - label1.Location.Y - label1.Height < 30)
                {
                    Button_No.Location = new Point(25, 25);
                }
                if (Button_No.Location.Y + Button_No.Height + 30 > label1.Location.Y &&
                Button_No.Location.Y + Button_No.Height - label1.Location.Y - label1.Height < 30)
                {
                    Button_No.Location = new Point(25, 25);
                }
            }
            if (Button_No.Top < 40)
                Button_No.Location = new Point(Button_No.Location.X, this.ClientSize.Height - Button_No.Height - 40);
            if (Button_No.Left < 40)
                Button_No.Location = new Point(this.ClientSize.Width - Button_No.Width - 40, Button_No.Location.Y);
            if (Button_No.Top > this.ClientSize.Height - Button_No.Height - 40)
                Button_No.Location = new Point(Button_No.Location.X, Button_No.Height + 40);
            if (Button_No.Left > this.ClientSize.Width - Button_No.Width - 40)
                Button_No.Location = new Point(Button_No.Width + 40, Button_No.Location.Y);



        }
    }
}

